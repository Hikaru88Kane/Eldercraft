package kamkeel.RPGMessenger.Util;

import org.bukkit.command.CommandSender;

public interface CommandDefault {

    public void runCMD(CommandSender sender, String label, final String[] args);

}
